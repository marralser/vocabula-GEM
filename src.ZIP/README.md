# Vocabula GEM 0.1

This is an experimental GEM/OpenGEM edition of Vocabula, the small vocabulary
trainer for DOS. It is a separate port: the working character-mode DOS edition
is not modified by this project.

The first milestone uses a native GEM application window and the GEM file
selector, while retaining Vocabula's plain-text lesson format and learning
rules. It deliberately does not use an `.RSC` resource file yet. This keeps the
source easy to build and change while the user interface is being tested.

## Implemented

- GEM window with redraw, move, resize, full-screen, and close handling
- Native GEM `.VOC` file selector
- Left-to-right, right-to-left, and mixed practice
- Answer checking with synonyms and optional articles
- Typo, capitalization, apostrophe, and spelling classifications
- F1 hint, F2 reveal, and an add-synonym button
- Three-attempt correction flow and forced retyping after reveal
- Score, progress indicator, mistake log, lesson statistics, and repetition
- Named high-score board and optional PC-speaker feedback
- Optional case-sensitive answer checking
- Editable Vocabula `.VOC` files; `/` and `,` can separate synonyms

## Lesson format

The first line names the two languages. Every following line is one card:

```text
English : German
the house : das Haus
watching, looking : sehen, schauen
```

Files should use DOS line endings and a DOS-compatible character encoding when
accented characters are required.

## Building

The supplied `MAKEFILE` targets Open Watcom C 1.9 in 16-bit large-memory mode:

```dos
wmake -f MAKEFILE
```

It additionally requires the BinaryMelodies OpenGEM bindings for Open Watcom.
Place the extracted binding tree in `GEMBIND`, build its `gembnd-l.lib` and
`samples/main-l.obj`, and then invoke the supplied makefile. Exact commands are
provided in `BUILDING.TXT`.

The result is `VCGEM.APP`. Copy the application and the `VOC` directory into an
OpenGEM-accessible directory, then launch it from the GEM desktop.

See [BUILDING.TXT](BUILDING.TXT) for the required GEM entry points and practical
porting notes.

## Controls

- `Ctrl+O`: select a lesson when none is open
- `Enter`: check the typed answer
- `Backspace`: edit the answer
- `F1`: show a hint
- `F2`: reveal the answer, which must then be retyped
- **Synonym**: confirm and save an unrecognised synonym
- `Esc` or **Stop**: end the session after confirmation

## Current preview limitations

- High scores use a compact GEM alert rather than a resource-based table.
- A menu bar is not yet included.
- The UI uses VDI drawing rather than a resource-editor-generated dialog tree.
- The code has been syntax-checked and its shared lesson engine tested on the
  development host, but the final `.APP` must be linked and tested with a real
  PC GEM SDK and GEM binding library.

